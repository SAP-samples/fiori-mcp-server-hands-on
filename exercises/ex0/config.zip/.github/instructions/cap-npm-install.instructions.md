---
description: "Use when installing npm dependencies in a CAP (Cloud Application Programming) project that contains a Fiori Elements or SAPUI5 app under `app/`. Enforces that `npm install` run at the CAP project root (which declares npm workspaces), never inside the nested `app/<appname>/` folder."
applyTo: "**/package.json"
---

# CAP + Fiori: Where to run `npm install`

- ✅ ALWAYS run `npm install` at the CAP project root (the folder that contains `srv/`, `db/`, `app/`, and the top-level `package.json`).
- ❌ NEVER run `npm install` (or any npm command that mutates deps) inside `app/<appname>/`, even though that folder has its own `package.json`.
