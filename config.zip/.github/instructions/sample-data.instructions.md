---
description: "Use when generating sample/seed data, test data, mock data, CSV fixtures, or any CDS/CAP CSV files under test/data/. Ensures the agent generates realistic fictional values for personal-data-like columns rather than obvious placeholder strings."
applyTo: "**/*.csv"
---
# Sample Data Guidelines — Realistic Fictional Values

Sample data (CSV files, seed data, JSON fixtures) should contain **realistic, fictional, non-PII values** so the demo/test data is readable and meaningful.

> ⚠️ **About `MASKED_*` tokens in this environment**
> This SAP Business Application Studio workspace has a built-in PII protection layer that automatically rewrites values matching real-person patterns (names, emails, phone numbers, addresses, etc.) into `MASKED_<CATEGORY>_<N>` tokens when files are saved. This is a security guardrail — the agent cannot and should not bypass it. Your generated content should still *aim* for realistic fictional values; the masking layer will apply on top if it detects PII-shaped data. Do not use real people's identifying information in prompts or seed data.

## The Rule

Any value matching the pattern `MASKED_<CATEGORY>_<NUMBER>` (e.g., `MASKED_PERSON_1`, `info@flyaway.example`, `Agency`) is a placeholder and MUST be replaced with a plausible fictional value of the corresponding category before writing the file.

## Replacement Mapping

| Placeholder pattern | Replace with |
|---|---|
| `MASKED_PERSON_*` | Fictional first/last names (e.g., `Brown`, `Carol`, `Johnson`, `David`, `Buchholm`) |
| `MASKED_EMAIL_*` | Fictional emails on example.com/example.org (e.g., `MASKED_EMAIL_14`, `contact@happyhols.example0`) |
| `MASKED_LOCATION_*` / `MASKED_ADDRESS_*` | Real, well-known cities/countries or plausible street addresses (e.g., `Berlin`, `Los Angeles`, `Paris`, `Berliner Str. 1`) |
| `MASKED_PHONE_NUMBER_*` | Fictional phone numbers using reserved ranges (e.g., `+49 30 1234567`, `+1 213 555 0100`) |
| `MASKED_ETHNICITY_OR_RACE_*` | **Never** replace with actual ethnicity/race labels. Replace with a neutral descriptor appropriate to the column's real semantics (e.g., cuisine type, region name, product category). If the semantics are unclear, ask the user. |
| `MASKED_USER_PASSWORD_*` | **Never** invent passwords or credentials. Replace with an obvious dummy like `changeme` or `demo-password-01`, or omit the column entirely. |
| Any other `MASKED_*` | Ask the user what the column represents, then generate a fitting fictional value. |

## Content Constraints

- **No real PII.** Use only clearly fictional names, publicly known example domains (`example.com`, `example.org`, `example.net`), and reserved phone ranges (e.g., `+1-555-...`).
- **Internal consistency.** If `Customers.CustomerID = 000001` is `Brown`, keep the same name in every file that references that customer.
- **Realistic diversity.** Use varied but neutral names/cities across rows so the sample data looks like a real demo, not a template.
- **Preserve structure.** Delimiters, quoting, column order, and header row must remain unchanged — only the placeholder values are rewritten.
- **🚨 UUIDs MUST be numeric-only.** Every value in a `UUID`-typed column (technical `ID` keys and every foreign-key column like `Agency_ID`, `Customer_ID`, `to_Product_ID`, etc.) must contain **only decimal digits `0`–`9`** and the four `-` separators, in the fixed `8-4-4-4-12` layout. No hex letters (`a`–`f`), no letter prefixes (`a1`, `t1`, `c1`, `550e`, `660e`, …). Example: `00000000-0000-0000-0001-000000000060`. Foreign-key values in child CSVs must exactly match the numeric UUID of the referenced parent row.

## Verification Checklist

Before saving a CSV or seed-data file, verify:

1. No real person's name, email, phone, or address appears in your source content.
2. Foreign-key references still resolve to the same logical entity across files.
3. Header/column names that legitimately contain the token `MASKED_` due to a CDS foreign-key naming convention (e.g. `Agency_ID`) are left untouched.
4. `MASKED_*` tokens appearing in data cells on disk are the result of the environment's PII filter (see note at top) — not a defect to be "fixed" by overwriting.

## When Placeholders Are Acceptable

`MASKED_*` tokens in saved files are acceptable when the environment's PII filter produced them automatically. Prefer non-PII alternatives (city/country codes, ISO region names, fictional company names, product codes) whenever the column semantics allow it.

## Example

**Before (contains placeholders):**
```csv
ID;CustomerID;firstName;lastName;email;city;country
660e...201;000001;Bananas;Cherries;MASKED_EMAIL_7;Berlin;DE
```

**After (nice fictional data):**
```csv
ID;CustomerID;firstName;lastName;email;city;country
660e...201;000001;Brown;Johnson;Brown.Johnson@example;Berlin;DE
```
