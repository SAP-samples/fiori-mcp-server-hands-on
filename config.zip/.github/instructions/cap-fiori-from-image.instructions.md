---
description: >
  Generates a full CAP Node.js project + SAP Fiori Elements app (FE_LROP)
  from a UI mockup image (screenshot, PNG, JPG, PDF, or similar). Follows a
  proven step-by-step playbook that avoids known pitfalls. Requires the
  sap-fiori-app-development skill to be active. Sample/seed CSV data must
  follow the sample-data instructions.
applyTo: "**"
---

# Task: Generate CAP + Fiori App from an Image

> **Before doing anything else, confirm you have read this entire instruction by stating:**
> **"Instruction `cap-fiori-from-image` loaded — starting Step 1."**

You are executing a well-defined playbook. Follow every step in order.
Do NOT skip steps or reorder them. The `sap-fiori-app-development` skill
governs annotation syntax and tool selection; this instruction governs
execution order and known pitfalls. Sample CSV generation MUST follow
[`sample-data.instructions.md`](./sample-data.instructions.md).

## Input required from the user
- **Image(s)** of the UI mockup (screenshot, PNG, JPG, PDF page, or design export)
- **Project name** (lowercase-dash, e.g. `travel-management`)
- **Main entity name** (e.g. `Travels`)

---

## Step 1 — Analyze the Image
Use the `view_image` tool to read each provided image file.

Extract from the visual design:
- **Entities & fields** — table columns, form fields, header info, section titles
- **Status codes & criticality** — coloured badges/pills (green = positive, orange = critical, red = negative)
- **Column labels** — exact wording as shown
- **Action buttons** — toolbar buttons, page-level actions, row actions
- **Filter bar fields** — anything shown above the table as a filter
- **Sample row data** — copy visible values verbatim so the demo matches the mockup

> ⚠️ Treat every value visible in the mockup as **fictional demo data**. When
> generating CSV seed data, follow [`sample-data.instructions.md`](./sample-data.instructions.md):
> use realistic fictional names/cities/emails, never real PII, and never
> obvious placeholders like `MASKED_PERSON_X` in the generated content.
> The workspace PII-masking layer may still rewrite values on save — that is
> expected and must not be "fixed" by overwriting.

If any part of the image is ambiguous (unreadable label, unclear data type,
unknown enum values), ask the user for clarification before proceeding.

---

## Step 2 — Initialize CAP Project
```bash
cd /home/user/projects
cds init <project-name> --nodejs
```
Do NOT manually edit `package.json`.

---

## Step 3 — Create `db/schema.cds`
- Every entity needs both a **technical key** (`UUID`) and a **business key** (Integer or String).
- `CurrencyCode : Currency` (from `@sap/cds/common`) expands to `CurrencyCode_code` in the DB — the CSV header must match.
- Use `managed` for audit fields, `Composition of many` for child entities, `Association to` for lookups.

---

## Step 4 — Create `srv/<service>.cds`
- Main entity: `@odata.draft.enabled`.
- Use `select from ... { *, case ... end as <field> : Integer }` to add computed fields (e.g. `criticality`). Criticality integer values map to colours: `3` = Positive (green), `2` = Critical (orange), `1` = Negative (red).
- Declare `actions { ... }` **inside** the entity block.
- Mark lookup entities `@readonly`.
- Do **not** use inline `--` comments inside `case` expressions (see pitfall #6).

---

## Step 5 — Plan `app/<app-name>/annotations.cds`
> ⚠️ **Do NOT create this file yet.** The Fiori generator (Step 8) will overwrite it regardless of the `generateFormAnnotations`/`generateLROPAnnotations` flags. Draft the content mentally or in a scratch note — you will write the actual file in Step 9, after generation completes.

---

## Step 6 — Create Sample Data CSVs in `test/data/`

**Before writing any CSV header**, run:
```bash
cds compile db --to sql | grep -A30 "CREATE TABLE <namespace>_<Entity>"
```
Use the **actual DB column names** from the output — never guess from CDS field names.

| CDS type | DB column |
|---|---|
| `CurrencyCode : Currency` | `CurrencyCode_code` |
| `Association` fields | not a column — omit |
| `managed` fields | omit (`createdAt` etc. are auto-filled) |

File naming: `<namespace>-<EntityName>.csv` (e.g. `travel.management-Travels.csv`)
UUID format: `550e8400-e29b-41d4-a716-446655440001` (increment last digits per row)

> ⚠️ **Sample data must follow [`sample-data.instructions.md`](./sample-data.instructions.md).**
> Use realistic fictional names, cities, and emails (e.g. `Brown`, `Johnson`,
> `Berlin`, `contact@example.com`), keep foreign-key references consistent
> across files, and never invent real PII. Do not write `MASKED_*` tokens
> yourself — those only appear via the environment's PII filter on save.

---

## Step 7 — Verify Compilation and Data Load
```bash
cds compile srv --for nodejs > /dev/null
cds deploy --to sqlite::memory:
```
Both must succeed before proceeding. Fix any errors before moving on.

---

## Step 8 — Generate Fiori App
Start the Fiori MCP server. You **must** use this MCP server for generating the Fiori App.
Call `mcp_fiori-mcp_generate_fiori_app_cap` with:
- `floorplan`: `"FE_LROP"`
- `generateFormAnnotations`: `false`
- `generateLROPAnnotations`: `false`
- `capType`: `"Node.js"`
- `servicePath`: use the `@path` value from `mcp_cds-mcp_search_model` output

> ⚠️ **Critical:** The generator will **unconditionally overwrite** `app/<app-name>/annotations.cds`. This is expected — you will replace it with your own annotations in Step 9. Do **not** create the annotations file before this step.
> Setting both flags to `false` keeps the generated scaffold minimal so Step 9's custom annotations are not polluted with auto-generated `UI.LineItem`, `UI.SelectionFields`, or `UI.FieldGroup` / `UI.Facets` entries that would conflict with the image-derived ones.

After generation:
```bash
npm install
```

---

## Step 9 — Write `app/<app-name>/annotations.cds`
Now create the annotations file you planned in Step 5. The generator has already run, so this file will not be overwritten.

- `UI.SelectionFields`: filter bar fields.
- `UI.LineItem`: table columns + `UI.DataFieldForAction` for toolbar buttons.
  - `UI.DataFieldForAction` format: `Action: '<ServiceName>.<actionName>'` (e.g. `'TravelService.acceptTravel'`).
- Status/criticality field: use `$Type: 'UI.DataField'` with a `Criticality` property (not `UI.DataFieldWithCriticality` — that type does not exist).
- `UI.HeaderInfo`, `UI.FieldGroup#<Qualifier>` + `UI.Facets` for the Object Page.
- Value help: `Common.ValueList` with `ValueListParameterInOut` + `ValueListParameterDisplayOnly`.
- Annotate the computed criticality integer field with `@UI.Hidden` so it doesn't appear as a standalone column.

After writing the file, verify compilation:
```bash
cds compile app --for nodejs > /dev/null
```

---

## Step 10 — Confirm
Report the generated app path and the run command:
```bash
npm run watch-<app-name>
```

Confirm that:
- CDS compilation passes (Step 9)
- The List Report shows the correct columns with criticality coloring on the status field, matching the image
- The Object Page shows the correct field groups, matching the image

---

## Known pitfalls (do not repeat these mistakes)
1. Use global `cds` binary — `npx cds` fails in this environment.
2. `CurrencyCode` in CSV must be `CurrencyCode_code`.
3. Always run `cds compile db --to sql` to confirm column names before writing CSVs.
4. `npm install` must run after Fiori app generation on CAP project root folder.
5. **Sample CSV data must follow [`sample-data.instructions.md`](./sample-data.instructions.md)** — use realistic fictional values, never invent real PII, and never write `MASKED_*` tokens yourself.
6. Do **not** use inline `--` comments inside CDS `case` expressions — they cause compile errors. Write comments on separate lines above the `when` clause, or omit them entirely.
7. **`UI.DataFieldWithCriticality` does not exist** — use `$Type: 'UI.DataField'` with a `Criticality` property pointing to the integer criticality element. Example:
   ```cds
   { $Type: 'UI.DataField', Value: TravelStatusText, Criticality: StatusCriticality, Label: 'Status' }
   ```
8. **Always annotate computed criticality fields with `@UI.Hidden`** — without it the integer field renders as a visible standalone column in the table. Add it in the property-level `annotate` block:
   ```cds
   annotate service.Travels with {
     StatusCriticality @UI.Hidden;
   }
   ```
9. **The Fiori generator overwrites `annotations.cds`** — even with `generateLROPAnnotations: false`. Write all UI annotations *after* the generator has run, not before.
10. **Always set both `generateLROPAnnotations: false` and `generateFormAnnotations: false`** when calling `mcp_fiori-mcp_generate_fiori_app_cap`. Setting either to `true` causes the generator to emit its own `UI.LineItem`, `UI.SelectionFields`, `UI.FieldGroup`, and `UI.Facets` into `annotations.cds`, which then conflict with the custom image-derived annotations written in Step 9 and require additional cleanup.
11. **Service handler `.js` files must use ES module syntax in CDS version 10 and above** — `cds init --nodejs` sets `"type": "module"` in `package.json`. Any `srv/*.js` action implementation must use `import`/`export`, never `require`/`module.exports`:
    ```js
    import cds from '@sap/cds';
    export default class TravelService extends cds.ApplicationService { ... }
    ```
12. **Ask when the image is ambiguous** — if a label, data type, or enum value cannot be read confidently from the image, ask the user rather than guessing.
