---
description: >
  Generates a full CAP Node.js project + SAP Fiori Elements app (FE_LROP)
  from a UI mockup image (screenshot, PNG, JPG, PDF, or similar). Follows a
  proven step-by-step playbook that avoids known pitfalls. Requires the
  sap-fiori-app-development skill to be active. Sample/seed CSV data must
  follow the sample-data instructions.
applyTo: "**"
---

# Task: Generate CAP + Fiori App from an Image

> **Before doing anything else, confirm you have read this entire instruction by stating:**
> **"Instruction `cap-fiori-from-image` loaded — starting Step 1."**

You are executing a well-defined playbook. Follow every step in order.
Do NOT skip steps or reorder them. The `sap-fiori-app-development` skill
governs annotation syntax and tool selection; this instruction governs
execution order and known pitfalls. Sample CSV generation MUST follow
[`sample-data.instructions.md`](./sample-data.instructions.md). Text
formatting of ID/description columns, filter chips, and value-help
dialogs MUST follow the `sap-fiori-text-arrangement` skill (see Step 5).

## Input required from the user
- **Image(s)** of the UI mockup (screenshot, PNG, JPG, PDF page, or design export)
- **Project name** (lowercase-dash, e.g. `product-catalog`)
- **Main entity name** (plural, e.g. `Products`)

---

## Step 1 — Analyze the Image
Use the `view_image` tool to read each provided image file.

Extract from the visual design:
- **Entities & fields** — table columns, form fields, header info, section titles
- **Status codes & criticality** — coloured badges/pills (green = positive, orange = critical, red = negative)
- **Column labels** — exact wording as shown
- **Action buttons** — toolbar buttons, page-level actions, row actions
- **Filter bar fields** — anything shown above the table as a filter
- **Sample row data** — copy visible values so the demo matches the mockup

> ⚠️ Treat every value visible in the mockup as **fictional demo data**. When
> generating CSV seed data, follow [`sample-data.instructions.md`](./sample-data.instructions.md)

If any part of the image is ambiguous (unreadable label, unclear data type,
unknown enum values), ask the user for clarification before proceeding.

---

## Step 2 — Initialize CAP Project
```bash
cd /home/user/projects
cds init <project-name> --nodejs
```
Do NOT manually edit `package.json`.

---

## Step 3 — Create `db/schema.cds`
- Every entity needs both a **technical key** (`UUID`) and a separate **business key** (Integer or String) marked with `@assert.unique`. The technical key is used for associations and drafts; the business key is what the user sees (e.g. a human-readable ID like `ProductID`, `CategoryID`, or `code` for code lists).
- For code-list style enums (e.g. a `ProductStatuses` entity) extend `sap.common.CodeList` so you get `name`/`descr` texts automatically; add a `criticality : Integer` element alongside `code`.
- Use `Currency` (from `@sap/cds/common`) for currency-code associations, never a plain `String`.

---

## Step 4 — Create `srv/<service>.cds`
- Main entity: `@odata.draft.enabled`.
- Use `select from ... { *, case ... end as <field> : Integer }` to add computed fields (e.g. `criticality`). Criticality integer values map to colours: `3` = Positive (green), `2` = Critical (orange), `1` = Negative (red).
- **Project the business key AND descriptive text of every association onto the main entity** so that `@Common.Text` can later point at a local property. See the `sap-fiori-text-arrangement` skill (Pattern A / Step 1) for the exact projection template.
- Declare `actions { ... }` **inside** the entity block.
- Mark lookup entities `@readonly`.
- Do **not** use inline `--` comments inside `case` expressions (see pitfall #6).

---

## Step 5 — Create `srv/<service>.ui.cds`
Create the UI annotations required for the service (`UI.HeaderInfo`, `UI.LineItem`, `UI.SelectionFields`, `UI.Facets`, `UI.FieldGroup#...`).

For text formatting of table columns, filter chips, value-help dialogs, semantic keys, code-list dropdowns, and any `@Common.Text` / `@Common.TextArrangement` / `@Common.ExternalID` / `@Common.ValueList` / `UI.Identification` annotations, apply the `sap-fiori-text-arrangement` skill at `.github/skills/sap-fiori-text-arrangement/SKILL.md`. That skill is the single source of truth for those patterns — do not re-derive them here.

Rules specific to this playbook (not covered by the skill):

- **`UI.SelectionFields` must reference the foreign-key column names**, not the association name — e.g. `Category_ID`, `Supplier_ID`, `ProductStatus_code`, `CurrencyCode_code`. Using the bare association name causes a runtime "field not found" in the filter bar.
- **Entity-level annotations combined with a property block must use the `with @( ... ) { ... }` form.** Do NOT append a top-level `@UI.Identification: [...];` after a closing `}` — the CDS parser rejects it.
- **Status column with criticality coloring** — use `$Type: 'UI.DataField'` with a `Criticality` property that points at the computed integer field:
  ```cds
  { $Type: 'UI.DataField', Value: ProductStatusText, Criticality: StatusCriticality, Label: 'Status' }
  ```
  and hide the criticality integer with `@UI.Hidden` (see pitfall #7).
- **Currency-typed amount fields must be annotated with `@Measures.ISOCurrency`.** Using the `Currency` type from `@sap/cds/common` alone does NOT make Fiori Elements render the currency next to the amount — the annotation must be added explicitly, pointing at the FK column (`CurrencyCode_code`):
  ```cds
  annotate service.Products with {
      UnitPrice @Measures.ISOCurrency: CurrencyCode_code;
      ListPrice @Measures.ISOCurrency: CurrencyCode_code;
  };
  ```
  Fiori then renders `3,450.00 USD` with right-aligned amount and the correct `minorUnit` (decimals) from the Currencies code list. The same pattern with `@Measures.Unit: <unitFK>` applies to units of measure.

---

## Step 6 — Create Sample Data CSVs in `test/data/`

File naming: `<namespace>-<EntityName>.csv` (e.g. `product.catalog-Products.csv`)
UUID format: `550e8400-e29b-41d4-a716-446655440001` (increment last digits per row)

Required CSVs:
- One CSV per entity in the model (main entity + all lookups + code lists).
- **When the app uses a specific currency (e.g. USD only), also seed `sap.common-Currencies.csv`** with at least that currency, otherwise the Currency value help will be empty:
  ```csv
  code;symbol;name;descr;minorUnit
  USD;$;US Dollar;United States Dollar;2
  ```
- Foreign-key columns follow the DB naming from `cds compile db --to sql` (e.g. `Category_ID`, `Supplier_ID`, `ProductStatus_code`, `CurrencyCode_code`).
- Code-list CSVs (entities extending `sap.common.CodeList`) use columns `code;name;descr;<extra fields>` — e.g. `code;name;descr;criticality`.

> ⚠️ **Sample data must follow [`sample-data.instructions.md`](./sample-data.instructions.md).**

---

## Step 7 — Verify Compilation and Data Load
```bash
cds compile srv --for nodejs > /dev/null
cds deploy --to sqlite::memory:
```
Both must succeed before proceeding. Fix any errors before moving on.

---

## Step 8 — Generate Fiori App
Start the Fiori MCP server. You **must** use this MCP server for generating the Fiori App.
Call `mcp_fiori-mcp_generate_fiori_app_cap` with:
- `floorplan`: `"FE_LROP"`
- `generateFormAnnotations`: `false`
- `generateLROPAnnotations`: `false`
- `capType`: `"Node.js"`
- `servicePath`: use the `@path` value from `mcp_cds-mcp_search_model` output

After generation:
```bash
npm install // on cap project root
```
---

## Step 9 — Confirm
Report the generated app path and the run command:
```bash
npm run watch-<app-name>
```

Confirm that:
- CDS compilation passes (Step 9)
- The List Report shows the correct columns with criticality coloring on the status field, matching the image
- The Object Page shows the correct field groups, matching the image

---

## Known pitfalls (do not repeat these mistakes)
1. Use global `cds` binary — `npx cds` fails in this environment.
2. `CurrencyCode` in CSV must be `CurrencyCode_code`.
3. Always run `cds compile db --to sql` to confirm column names before writing CSVs.
4. `npm install` must run after Fiori app generation on CAP project root folder.
5. Do **not** use inline `--` comments inside CDS `case` expressions — they cause compile errors. Write comments on separate lines above the `when` clause, or omit them entirely.
6. **`UI.DataFieldWithCriticality` does not exist** — use `$Type: 'UI.DataField'` with a `Criticality` property pointing to the integer criticality element. Example:
   ```cds
   { $Type: 'UI.DataField', Value: ProductStatusText, Criticality: StatusCriticality, Label: 'Status' }
   ```
7. **Always annotate computed criticality fields with `@UI.Hidden`** — without it the integer field renders as a visible standalone column in the table. Add it in the property-level `annotate` block:
   ```cds
   annotate service.Products with {
     StatusCriticality @UI.Hidden;
   }
   ```
8. **NEVER put `@UI.Hidden` on the TEXT field referenced by a `UI.DataField` with `Criticality:`.** `@UI.Hidden` suppresses the field from every UI context — including the LineItem cell that references it — so the column renders empty and criticality coloring never appears. Only the *integer criticality helper* gets `@UI.Hidden`; the *text value* stays visible:
   ```cds
   // In LineItem: value = text, criticality = integer helper
   { $Type: 'UI.DataField', Value: StatusText, Criticality: StatusCriticality, Label: 'Status' }

   // Property-level: hide ONLY the integer
   annotate service.Travels with {
     StatusCriticality @UI.Hidden;   // ✅ hide integer helper
     // StatusText     @UI.Hidden;   // ❌ NEVER — kills the whole column
   };
   ```
   The same rule applies to any helper text projected from an association (e.g. `AgencyName`, `CustomerFullName`) — only hide it if it is NOT referenced by any `UI.DataField.Value`. If it IS referenced (directly or via `@Common.Text` chain), leave it visible; Fiori Elements will render it inside the referencing cell.
9. **Service handler `.js` files must use ES module syntax in CDS version 10 and above** — `cds init --nodejs` sets `"type": "module"` in `package.json`. Any `srv/*.js` action implementation must use `import`/`export`, never `require`/`module.exports`:
    ```js
    import cds from '@sap/cds';
    export default class CatalogService extends cds.ApplicationService { ... }
    ```
10. **Ask when the image is ambiguous** — if a label, data type, or enum value cannot be read confidently from the image, ask the user rather than guessing.
11. **Currency next to amount requires `@Measures.ISOCurrency`.**
