---
name: sap-fiori-text-arrangement
description: Render "text + ID" cells, filter chips, value helps, code-list dropdowns, and semantic keys in SAP Fiori Elements using `@Common.Text`, `@Common.TextArrangement`, `@Common.SemanticKey`, and `@Common.ExternalID` (for UUID-keyed associations). Use for two-line cells, readable business IDs in chips/value helps, or fixing draft indicators on the wrong column.
argument-hint: Entity, ID property, descriptive-text property, arrangement (TextFirst / TextLast / TextOnly / TextSeparate), whether target key is a UUID
metadata:
  author: sap-fiori-tools
  version: "0.0.1"
---

# SAP Fiori Text Arrangement

## Purpose

Three related, frequently combined features:

1. **Two-line "text + ID" cells** in a List Report / Object Page column — bold description on top, subdued business key below (or reversed).
2. **Semantic key** — designates the primary identifying column so it renders as the bold `ObjectIdentifier` and hosts the draft / edit status indicator.
3. **Readable business keys in filter chips and value-help dialogs** when the underlying association uses a UUID/GUID primary key.

Driven by four annotations:

| Annotation                  | Purpose                                                              |
|----------------------------|----------------------------------------------------------------------|
| `@Common.Text`             | Points to the descriptive-text property (or a path into a target).   |
| `@Common.TextArrangement`  | Controls visual order (`#TextFirst` / `#TextLast` / `#TextOnly` / `#TextSeparate`). |
| `@Common.SemanticKey`      | Marks the business-key column(s) as the primary identifier of the entity (bold rendering, draft indicators). |
| `@Common.ExternalID`       | Redirects a GUID key to a readable business-key field (value help + filter chip). |

> All CDS snippets use a **generic Sales-Order** scenario (`SalesService.Orders`, `Products`, `Suppliers`, `OrderStatuses`). Substitute your own service, entity, and property names.

---

## Required Inputs (ask if missing)

1. **Entity** (e.g. `MyService.Orders`).
2. **ID property** referenced in `UI.LineItem` / `UI.FieldGroup` (e.g. `OrderID`, `ProductID`).
3. **Descriptive-text property** (e.g. `Description`, `ProductName`) — must be a property of the same service entity or reachable via association path.
4. **Arrangement** — see the table below.
5. **UUID key on association target?** If yes, plan `Common.ExternalID` too.

---

## `TextArrangement` — Visual Reference

| Value           | Two-line cell           | Single-line / chip / value-help | Example                       | Typical use                                              |
|-----------------|-------------------------|---------------------------------|-------------------------------|----------------------------------------------------------|
| `#TextFirst`    | Text / ID               | `Text (ID)`                     | `Coffee Beans (P-0001)`       | **Most mockups.** Names take priority over IDs.          |
| `#TextLast`     | ID / Text               | `ID (Text)`                     | `P-0001 (Coffee Beans)`       | ID-forward views: product codes, technical lists.        |
| `#TextOnly`     | Text                    | `Text`                          | `Confirmed`                   | Technical code hidden from the user.                     |
| `#TextSeparate` | ID                      | `ID` (text kept for search)     | `P-0001`                      | Text belongs in a **separate column** — tables only.     |
| *(omitted)*     | Fiori picks per context | Fiori picks per context         | —                             | **Best default** for associations — let FE decide.       |

> Omitting `TextArrangement` on an **association** is often the cleanest choice: Fiori Elements renders `ID (Text)` in chips and value helps automatically once the `Text` chain is set up.

---

## `Common.SemanticKey` — Mark the Primary Business Key

`SemanticKey` tells Fiori Elements which column(s) represent the **user-visible business key** of the entity. It has two visible effects in the List Report:

1. That column is rendered as a bold `sap.m.ObjectIdentifier` (the two-line text+ID layout).
2. The **draft / edit / lock indicators** are placed on that column (not on the technical UUID key).

Set it on **every draft-enabled entity** — the technical `key ID : UUID` is not what the user identifies rows by.

```cds
annotate SalesService.Orders with @(
    Common.SemanticKey: [ OrderID ]         // business key, NOT the UUID
);
```

**Notes**

- Array-valued: for a composite business key use `[ Field1, Field2 ]`.
- Place `SemanticKey` on the **service-level entity**, alongside `UI.LineItem` / `UI.HeaderInfo`.
- `SemanticKey` alone does **not** create the two-line cell — pair with `@Common.Text` + `@Common.TextArrangement` (Pattern A) to get bold-text-over-subdued-ID.
- If a mockup shows draft indicators on the wrong column, the fix is almost always a missing or wrong `SemanticKey`.

---

## Pattern A — Two-Line Cell in a Table (`#TextFirst`)

**Goal:** Column cell shows the descriptive text bold on top, business ID subdued below.

### Step 1 — Project the text onto the same entity (if it lives on an association)

`@Common.Text` on a **column** works best when the text is a property of the same service entity. Expose it via the projection:

```cds
// srv/sales-service.cds
service SalesService {
    @odata.draft.enabled
    entity Orders as select from db.Orders {
        *,
        to_Product.ProductID   as ProductID   : String,
        to_Product.Name        as ProductName : String,
        to_Supplier.SupplierID as SupplierID  : String,
        to_Supplier.Name       as SupplierName: String
    };
    @readonly entity Products  as projection on db.Products;
    @readonly entity Suppliers as projection on db.Suppliers;
}
```

### Step 2 — `UI.LineItem` references the **ID** property; declare `SemanticKey`

```cds
annotate SalesService.Orders with @(
    Common.SemanticKey: [ OrderID ],   // primary business key → bold column + draft indicator
    UI.LineItem: [
        { $Type: 'UI.DataField', Value: OrderID,    Label: 'Order ID' },
        { $Type: 'UI.DataField', Value: ProductID,  Label: 'Product' },
        { $Type: 'UI.DataField', Value: SupplierID, Label: 'Supplier' }
    ]
);
```

### Step 3 — Annotate the ID property and hide the helper text

```cds
annotate SalesService.Orders with {
    OrderID    @Common.Text: Description   @Common.TextArrangement: #TextFirst;
    ProductID  @Common.Text: ProductName   @Common.TextArrangement: #TextFirst;
    SupplierID @Common.Text: SupplierName  @Common.TextArrangement: #TextFirst;

    ProductName   @UI.Hidden;
    SupplierName  @UI.Hidden;
};
```

> ⚠️ **Never `@UI.Hidden` a helper text that is referenced by another `UI.DataField.Value`** (for example a `StatusText` used inside a `{ Value: StatusText, Criticality: … }` DataField). `@UI.Hidden` suppresses the field from every UI context, including the referencing cell — the column will render empty. Only hide fields that are exclusively used as the target of `@Common.Text` (like `ProductName` above, which never appears as a `Value:`).

---

## Pattern B — Filter Chip + Value Help with UUID Keys

**Goal:** Filter chip shows `P-0001 (Coffee Beans)` (not the raw GUID). Value-help popup shows the readable ID column, not the UUID.

Reference: [SAP UI5 docs — Handling of GUID-Based Fields with Readable ID Fields](https://ui5.sap.com/#/topic/3faed838512648b099e14dfec458d847).

### The Chain

For a filter on `Orders.to_Product`, Fiori Elements walks:

```
Orders.to_Product_ID (UUID)
  ─ ExternalID ─▶ Products.ProductID     (redirect UUID → business key)
  ─ Common.Text ▶ Products.ProductID     (path used for chip label)
  ─ Common.Text ▶ Products.Name          (chained on target's business key)
  ⇒ renders "P-0001 (Coffee Beans)"
```

### CDS pattern

```cds
// srv/sales-service.ui.cds

// 1) On the value-help entity: redirect UUID key → business key,
//    and pair the business key with the descriptive name.
annotate SalesService.Products with {
    ID        @Common.ExternalID: ProductID;
    ProductID @Common.Text      : Name;      // NO TextArrangement — let FE decide
};

annotate SalesService.Suppliers with {
    ID         @Common.ExternalID: SupplierID;
    SupplierID @Common.Text      : Name;
};

// 2) On the main entity: annotate the ASSOCIATION (not the FK column).
//    CAP flattens these annotations onto to_Product_ID / to_Supplier_ID at compile time.
//    Use a path (to_Product.ProductID) for Common.Text.
annotate SalesService.Orders with {

    to_Product @(
        Common.Label     : 'Product',
        Common.Text      : to_Product.ProductID,
        Common.ExternalID: to_Product.ProductID,
        Common.ValueList : {
            $Type          : 'Common.ValueListType',
            CollectionPath : 'Products',
            Parameters     : [
                { $Type: 'Common.ValueListParameterInOut',
                  LocalDataProperty: to_Product_ID, ValueListProperty: 'ID' },
                { $Type: 'Common.ValueListParameterDisplayOnly',
                  ValueListProperty: 'Name' }
            ]
        }
    );

    to_Supplier @(
        Common.Label     : 'Supplier',
        Common.Text      : to_Supplier.SupplierID,
        Common.ExternalID: to_Supplier.SupplierID,
        Common.ValueList : { /* similar */ }
    );
};
```

### Rules that make it work

- **Annotate the association**, not the flattened FK. Writing `annotate ... { to_Product_ID @... }` produces `Element "to_Product_ID" has not been found` warnings, even though the SQL column exists. CAP flattens association-level annotations onto the FK automatically.
- **Use a path expression in `Common.Text`** (`to_Product.ProductID`) — this reaches into the target entity so the chain can continue.
- **Don't set `TextArrangement` on the association.** Omitting it lets Fiori Elements pick the correct rendering for filter chips (`ID (Text)`) and value-help dialogs.
- **`ExternalID` is required in two places:** the target entity's UUID key AND the source association. Setting it on only one side leaves a UUID leaking through the other.
- **Do NOT list the business-key ID as a `ValueListParameterDisplayOnly`** when the target entity already defines a `UI.LineItem` that includes that column. Fiori Elements merges both sources and renders the ID column twice in the value-help dialog. Keep only the `InOut` parameter (bound to the UUID `ID`) and `DisplayOnly` parameters for the *descriptive* fields (e.g. `Name`) — the readable business key is contributed automatically via `Common.Text` + `Common.ExternalID` and the target's `UI.LineItem`.

### Not needed for code lists

Entities extending `sap.common.CodeList` already have readable `code` keys (e.g. `A`, `O`, `X`). Use `Common.Text: name` + `TextArrangement: #TextOnly` alone — **no `ExternalID`**.

---

## Pattern C — Code List as Dropdown (`ValueListWithFixedValues`)

**Goal:** Render a small fixed set of values (statuses, priorities, categories) as a **ComboBox dropdown** in the filter bar and Object Page — not as a full value-help dialog. Show the readable text only, hide the technical `code`.

**When to use:** Any entity extending `sap.common.CodeList` with a small, closed set of values (typically < 20 entries).

### CDS pattern

```cds
// 1) On the code list entity: text arrangement on the code key
annotate SalesService.OrderStatuses with @(
    UI.Identification: [ { Value: name } ],
    UI.LineItem      : [
        { $Type: 'UI.DataField', Value: code, Label: 'Status Code' },
        { $Type: 'UI.DataField', Value: name, Label: 'Status' }
    ]
) {
    code @Common.Text: name @Common.TextArrangement: #TextOnly;
};

// 2) On the main entity's association: force dropdown rendering + TextOnly
annotate SalesService.Orders with {
    to_Status @(
        Common.Label                   : 'Status',
        Common.Text                    : to_Status.name,
        Common.TextArrangement         : #TextOnly,
        Common.ValueListWithFixedValues: true,           // ⇒ ComboBox dropdown
        Common.ValueList               : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'OrderStatuses',
            Parameters    : [
                { $Type: 'Common.ValueListParameterInOut',       LocalDataProperty: to_Status_code, ValueListProperty: 'code' },
                { $Type: 'Common.ValueListParameterDisplayOnly', ValueListProperty: 'name' }
            ]
        }
    );
};
```

### Rules that make it work

- **`Common.ValueListWithFixedValues: true`** on the association is what switches the control from value-help dialog → ComboBox dropdown. Without it, even small code lists open a full-screen dialog.
- **`Common.TextArrangement: #TextOnly` in TWO places:** on the code list's `code` key AND on the source association. Both are required — the first governs cell/chip rendering, the second governs the dropdown entries.
- **The `UI.LineItem` on the code list is still used** by the dropdown's search/type-ahead popup. Keep both `code` and `name` columns; `TextOnly` hides the technical code in the visible chip/cell but users can still filter by it if needed.
- **Do NOT use `Common.ExternalID`** — code list keys are already readable strings, not UUIDs. Adding `ExternalID` causes redundant annotations.

### Verify

- **Filter bar** — Status field renders as a dropdown; opening it shows readable text values (e.g. `Confirmed`, `Open`, `Canceled`) with no technical codes visible.
- **Table cell** — Status column shows only the text (with criticality coloring if configured).
- **Object Page edit mode** — Status field is a ComboBox, not a value-help dialog button.

---

## Verify

```bash
cds compile srv --for nodejs > /dev/null && echo COMPILE_OK
```

Then in the running app confirm:

- **Column cells** — two-line layout renders as expected.
- **Filter chip** — shows the readable label (e.g. `P-0001 (Coffee Beans)`), not a UUID.
- **Value-help popup** — has no UUID column; readable ID + name are visible.
- **Applied filter** — still returns correct rows (OData uses the GUID under the hood).

---

## Known Pitfalls

1. **LineItem points at the text.** `Value: ProductName` disables the two-line rendering. Always point at the **ID** and let `@Common.Text` supply the text.
2. **Missing `@UI.Hidden` on the helper text column.** Without it, `ProductName` / `SupplierName` render as extra columns beside the two-line cell.
3. **`@UI.Hidden` on a helper text that IS referenced by a `UI.DataField.Value`.** `@UI.Hidden` suppresses the field from every UI context, including the referencing cell — the column renders empty (e.g. a Status column with criticality coloring goes blank). Only hide helpers that are pure `@Common.Text` targets and never used as `Value:` anywhere.
4. **`TextArrangement` without `Text`** does nothing. They must appear on the same field.
5. **Forcing `#TextLast` on an association.** It fights the value-help dialog's own layout. Prefer omitting `TextArrangement` on associations; use it on **projected business-key columns** (Pattern A) instead.
6. **Annotating `to_Product_ID` directly** at the entity level produces `Element "to_Product_ID" has not been found`. Annotate the **association** (`to_Product`) — CAP flattens it onto the FK.
7. **`ExternalID` on only one side.** Both the value-help entity's GUID key and the main entity's association need it, or a UUID will still appear in either the chip or the dialog.
8. **`ExternalID` on `sap.common.CodeList` keys.** Unnecessary — `code` is already readable. Use `Common.Text` + `#TextOnly`.
9. **Wrong arrangement enum.** Fiori is strict — `#TextFirst`, `#TextLast`, `#TextOnly`, `#TextSeparate`. The leading `#` is required.
10. **Applies to `UI.DataField` only.** `UI.DataFieldWithIntentBasedNavigation`, `Communication.Contact`, etc. do NOT honor `TextArrangement`.
11. **`SemanticKey` set to the UUID key.** Placing the technical `ID` (UUID) in `SemanticKey` puts draft indicators on the wrong column. Use the **business key** (`OrderID`, `ProductID`) instead.
12. **Missing `SemanticKey` on a draft entity.** Draft/edit indicators end up on an arbitrary column, and the ObjectIdentifier bold rendering may not activate.
13. **Duplicate ID column in the value-help dialog.** Caused by listing the business-key ID as both a `UI.LineItem` field on the target entity AND a `ValueListParameterDisplayOnly` on the source association. Drop the `DisplayOnly` entry for the ID — keep only descriptive fields (`Name`, …) as `DisplayOnly` parameters.
14. **Code list rendered as full value-help dialog instead of dropdown.** Missing `Common.ValueListWithFixedValues: true` on the association. Add it for small closed code lists (Pattern C) — Fiori Elements will render a ComboBox in filter bar and Object Page.
15. **Technical codes leaking into filter chips or dropdown.** `TextArrangement: #TextOnly` must be set on **both** the code list's `code` key AND the source association. Setting it in only one place still shows the code in the other UI surface.

---

## Troubleshooting

**Both lines show the same value** → check that the text field is populated and points at a distinct property.

**Only the ID appears, no text** → text field is empty in seed data, or not `$select`-able (check for `@cds.api.ignore` / non-projected fields).

**`TextArrangement` seems ignored** → verify both annotations are on the same field; hard-reload with `?sap-ui-xx-viewCache=false`.

**Value help shows a UUID column** → see Pattern B. `ExternalID` must be on **both** the target entity's UUID key AND the source association.

**Filter chip still shows a UUID** → the `ExternalID` on the association is missing; annotate the association (not the FK column).

**Value help dialog shows the ID column twice** → the business-key ID is declared both by the target entity's `UI.LineItem` and by a `ValueListParameterDisplayOnly` on the association's `Common.ValueList`. Remove the `DisplayOnly` entry for the ID; keep only descriptive columns as `DisplayOnly` parameters.

**Code list opens as a full value-help dialog** → add `Common.ValueListWithFixedValues: true` on the association (Pattern C). Fiori Elements will render a ComboBox dropdown instead.

**Dropdown / filter chip still shows the technical code** → `TextArrangement: #TextOnly` is missing on the code list's `code` key or on the source association. Set it in both places.

**Draft / edit indicator appears on the wrong column** → add or fix `Common.SemanticKey: [ <businessKey> ]` on the entity. Never point it at the UUID technical key.

**Primary column not bold** → `SemanticKey` is missing on the entity, or the column referenced by `UI.LineItem` doesn't match the semantic-key field.

**Status column with criticality renders empty** → the text field referenced by the LineItem cell (e.g. `Value: StatusText, Criticality: StatusCriticality`) is marked `@UI.Hidden`. Remove `@UI.Hidden` from the text; keep it only on the integer criticality helper.

---

## References

- SAP UI5 docs — [Handling of GUID-Based Fields with Readable ID Fields](https://ui5.sap.com/#/topic/3faed838512648b099e14dfec458d847)
- SAP UI5 docs — [Displaying Readable IDs Instead of Edm.Guid Values Using Common.ExternalID](https://ui5.sap.com/topic/f49a0f7eaafe444daf4cd62d48120ad0.html)
- Related skill: `sap-fiori-app-development` for general Fiori Elements guidelines.
